<!--
<nav>
  <ul>
    <li><a href="<?php //echo __SITE_URL; ?>/index.php?rt=home">Home</a></li>
    <li><a href="<?php //echo __SITE_URL; ?>/index.php?rt=pretrazi">Pretra�i</a></li>
    <li><a href="<?php //echo __SITE_URL; ?>/index.php?rt=profil">Profil</a></li>
  </ul>
</nav>
-->
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav" >
    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Home">
          <a class="nav-link" href="<?php echo __SITE_URL; ?>/index.php?rt=home">
            <i class="fa fa-home" aria-hidden="true"></i>
            <span class="nav-link-text">Home</span>
          </a>
        </li>
