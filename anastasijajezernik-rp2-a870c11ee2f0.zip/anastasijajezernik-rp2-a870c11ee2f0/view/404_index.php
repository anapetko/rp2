<?php require_once __SITE_PATH . '/view/_header.php'; ?>
<title> <?php echo $title; ?> </title>
<?php require_once __SITE_PATH . '/view/_footer.php'; ?>
