<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Profile">
      <a class="nav-link" href="<?php echo __SITE_URL; ?>/index.php?rt=user">
        <i class="fa fa-user-circle"></i>
        <span class="nav-link-text">Profile</span>
      </a>
    </li>

<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Drive">
  <a class="nav-link" href="<?php echo __SITE_URL; ?>/index.php?rt=pretrazi">
    <i class="fa fa-car" aria-hidden="true"></i>
    <span class="nav-link-text">Drive</span>
  </a>
</li>
