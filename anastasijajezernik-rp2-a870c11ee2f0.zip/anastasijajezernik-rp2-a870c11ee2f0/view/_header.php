<?php
//echo '$_SESSION:';  print_r( $_SESSION );    echo "</br></br>";
//echo '$_POST:';  print_r( $_POST );   echo "</br></br>";
//echo '$_GET:';  print_r( $_GET );   echo "</br></br>";
 ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Bootstrap core CSS-->
  <link href="<?php echo __SITE_URL; ?>/view/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo __SITE_URL; ?>/view/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="<?php echo __SITE_URL; ?>/view/css/sb-admin.css" rel="stylesheet">
  <link href="<?php echo __SITE_URL; ?>/css/style.css" rel="stylesheet">

  <!--
  <link rel="stylesheet" href="<?php //echo '__SITE_URL';?>/css/style.css">
  -->
  <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
  <script src="<?php echo __SITE_URL;?>/js/skripta.js"></script>

  <!-- iza ide jos title, po potrebi ako nesto bas za tu stranicu treba i </head> i onda <body> -->
