# RP2

Posao:

- kreiranje baza i ubacivanje nekoliko primjera za testiranje (16.5.) - Anastasija
- logiranje i registriranje (18.5.) - Maja
- ispis vožnje (24.5.) - Ana
- uređivanje i dodavanje nove vožnje (27.5.) - Ema
- rezervacija vožnje (29.5.) - Ana
- dodana većina dijela u vezi osobnog profila (treba jos dodati neke funkcije, ispise, stupac u bazu) (04.06.) - Anastasija
- dodan dio funkcija za osobni profil (treba još samo omogućiti ubacivanje komentara i ocjena + treba malo modificirati bazu),
  dodana tablica u bazu (deleted_drive), dodan contact dio (controller i view) (07.07.) - Anastasija
- dodavanje uploadanja i brisanja profilne slike, klik na username koji vodi do tuđeg profila (7.7.) - Maja
- dodan ostatak "profila" (povijest voznji, followeri, unos ocjena + komentara) (7.7.) - Anastasija
- omogućavanje (un)followanja (8.7.) - Maja
